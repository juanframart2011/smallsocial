<div class="container">
<div class="row">
<div class="col-md-12">
<h2>Log de cambios</h2>
<p>En esta pagina puedes ver todos los cambios ejercidos en el proyecto <b>smile</b>.</p>
<h4>v1.0</h4>
<p><b>Modulos</b></p>
<ul>
	<li>Usuarios</li>
	<li>Publicaciones</li>
	<li>Perfiles</li>
	<li>Likes</li>
	<li>Comentarios</li>
	<li>Imagenes</li>
	<li>Amigos</li>
	<li>Mensajes</li>
	<li>Notificaciones</li>
</ul>

<p><b>Caracteristicas</b></p>
<ul>
	<li>Dar like a estados e imagenes</li>
	<li>Escribir comentarios a estados e imagenes</li>
	<li>Buscar y ver amigos, solicitud de amistad (enviar y aceptar)</li>
	<li>Enviar mensajes a amigos</li>
</ul>
<p>Y muchas cosas mas implicitas.</p>

</div>
</div>
</div>
