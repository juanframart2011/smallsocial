<div class="list-group">
  <a href="./?view=editinformation" class="list-group-item">Informacion Personal</a>
  <a href="./?view=editbasicinfo" class="list-group-item">Informacion Basica</a>
<!--  <a href="./?view=editcontactinfo" class="list-group-item">Informacion de Contacto</a>-->
</div>
