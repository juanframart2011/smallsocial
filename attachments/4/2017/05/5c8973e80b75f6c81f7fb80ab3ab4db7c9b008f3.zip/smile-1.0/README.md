# SMILE
Red social de proposito general con PHP y MySQL

### Descripcion
SMILE es un sistema de red social en el que podemos rellenar nuestro perfil, hacer publicaciones de texto y/o imagenes, buscar amigos, enviar, recibir y aceptar solicitudes de amistad y enviar mensajes a amigos, comentar y/o dar likes a las publicaciones, recibir notificaciones y mucho mas.

### Dedicatoria
Este sistema se lo dedico a mis padres(Agustin Ramos de la Cruz y Maria de Lourdes Escalante Mendez) por que desde que empece en el mundo de las computadoras ellos me dieron su apoyo emocional y economico, me compraron computadoras, me pagaron mis estudios universitarios, estoy muy agradecido con ellos, los amo.

### Modulos
Defino a grandes rasgos los modulos generales del sistema

- Usuarios
- Publicaciones
- Perfiles
- Likes
- Comentarios
- Imagenes
- Amigos
- Mensajes
- Notificaciones

### Bugs conocidos
Todavia no lo he probado al 100%, pero escribo algunas cosas que no he programado pero las ire haciendo poco a poco.

- Modulo de super administrador: permitira tener el control total de todo el sistema, no desarrollado.
- Notificaciones por correo: el sistema no envia ninguna notificacion al correo, para nada.
- Privacidad: Otros usuarios pueden ver y comentar aun sin ser amigos.
