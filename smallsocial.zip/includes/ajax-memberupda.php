<?php


   // Incluimos las funciones del sistema
   require_once '../administrator/ss-functions.php';

   // Revisamos si existe la sesion o si es valida
   isuserajaxadm();


 