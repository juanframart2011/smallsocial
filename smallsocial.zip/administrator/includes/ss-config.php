<?php

// Datos del Hosting para la conexion a la Base de Datos
define('HOST', 'localhost');
define('DBUSER', 'root');
define('DBPASSWORD', 'mysql');
define('DBNAME', 'smallsocial');


// Complementos para contraseñas
define('SALT', 'QVLteljhMM9TfFw7JE811AOxsAW8e3w6');
define('PEPER', 'k1rd7bm3jtzJlFm66Bqyjl1AW7316zbX');

// Complementos para la verficacion del email

define('TOKENMAIL', 'B920WI1H28W1AlpSHJLzsf7Q4Dcrge55');


// Prefijo del sistema, por defecto es "jhss_" pero se recomienda cambiarlo.
define('SSPREFIX', 'jhss_');
