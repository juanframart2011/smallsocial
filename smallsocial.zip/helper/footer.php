<footer class="container-fluid">
	<div class="row">
		<div class="col-lg-2 col-lg-offset-2 col-md-2 col-md-offset-2 col-sm-6 col-xs-12 text-center">
			<span class="title">**********</span><br>
			<span></span>
		</div>
		<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 text-center">
			<span class="title">DESCARGA LA APP</span><br>
			<div class="row">
	<a class="col-lg-4 col-md-4" href="#"><img class="img-responsive" src="http://i.imgur.com/iMwj03B.png" alt=""></a></i></a>
	<a class="col-lg-4 col-md-4" href="#"><img class="img-responsive" src="http://i.imgur.com/Gi7aDV8.png" alt=""></a></i></a>
	<a class="col-lg-4 col-md-4" href="#"><img class="img-responsive" src="http://i.imgur.com/yCwJq5Z.png" alt=""></a></i></a>
		</div>
			</span>
			</span>
		</div>
		<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 text-center">
			<span class="title">SÍGUENOS</span><br>
			<div class="row">
				<a class="col-lg-4 col-md-4" href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				<a class="col-lg-4 col-md-4" href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				<a class="col-lg-4 col-md-4" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
			</div>
		</div>
		<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 text-center">
			<span class="title">MEETEAM</span><br>
			<span>2017</span>
		</div>
	</div>
</footer>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<!-- AdminLTE -->
<script src="js/AdminLTE.js"></script>
<script src="js/jquery.validate.min.js"></script>
<!-- SS Normal -->
<script src="js/ss-normal.js"></script>