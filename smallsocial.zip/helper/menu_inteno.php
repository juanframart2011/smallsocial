<div class="description-block" style="text-align:center;">
    <a href="home.php" class="btn btn-sm btn-success"><i class="fa fa-clock-o"></i> Inicio</a>
    <a href="myinformation.php" class="btn btn-sm btn-info active"><i class="fa fa-info-circle"></i> Información</a>
    <a href="mypictures.php" class="btn btn-sm bg-navy"><i class="fa fa-picture-o"></i> Fotos</a>
    <a href="myvideos.php" class="btn btn-sm bg-navy"><i class="fa fa-video-camera" aria-hidden="true"></i> Videos</a>
    <a href="myfollowers.php" class="btn btn-sm btn-danger"><i class="fa fa-users"></i> Seguidores</a>
    <a href="search.php" class="btn btn-sm bg-gray"><i class="fa fa-users"></i> Buscar Usuarios</a>
</div>